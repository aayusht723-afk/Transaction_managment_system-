"""Colours, fonts and ttk styling used across the interface."""

from tkinter import ttk

# Palette
BG = "#13151b"
SURFACE = "#1b1e26"
SURFACE_ALT = "#222633"
SURFACE_HOVER = "#2c3143"
BORDER = "#2e3340"

TEXT = "#e9ebf1"
TEXT_MUTED = "#8b93a3"
TEXT_DARK = "#12141a"

ACCENT = "#4f8cff"
ACCENT_HOVER = "#6a9dff"
ACCENT_ACTIVE = "#3a6fd8"

INCOME = "#5fdc9b"
EXPENSE = "#ff8080"
WARNING = "#ffc078"

# Fonts
FONT = "Segoe UI"
F_BODY = (FONT, 10)
F_BOLD = (FONT, 10, "bold")
F_SMALL = (FONT, 9)
F_SMALL_BOLD = (FONT, 9, "bold")
F_SECTION = (FONT, 11, "bold")
F_TITLE = (FONT, 16, "bold")
F_CARD = (FONT, 17, "bold")


def apply_theme(root):
    """Switch to the clam theme and restyle the ttk widgets we use."""
    style = ttk.Style(root)
    style.theme_use("clam")

    root.configure(bg=BG)
    _style_menus(root)
    _style_entries(style)
    _style_tree(style)
    _style_scrollbar(style)

    return style


def _style_menus(root):
    root.option_add("*Menu.background", SURFACE_ALT)
    root.option_add("*Menu.foreground", TEXT)
    root.option_add("*Menu.activeBackground", ACCENT)
    root.option_add("*Menu.activeForeground", "#ffffff")
    root.option_add("*Menu.borderWidth", 0)
    root.option_add("*Menu.relief", "flat")
    root.option_add("*TCombobox*Listbox.background", SURFACE_ALT)
    root.option_add("*TCombobox*Listbox.foreground", TEXT)
    root.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
    root.option_add("*TCombobox*Listbox.selectForeground", "#ffffff")


def _style_entries(style):
    style.configure(
        "TEntry",
        fieldbackground=SURFACE_ALT,
        background=SURFACE_ALT,
        foreground=TEXT,
        insertcolor=TEXT,
        bordercolor=BORDER,
        lightcolor=BORDER,
        darkcolor=BORDER,
        borderwidth=1,
        relief="flat",
        padding=6,
    )
    style.map(
        "TEntry",
        bordercolor=[("focus", ACCENT)],
        lightcolor=[("focus", ACCENT)],
        darkcolor=[("focus", ACCENT)],
        fieldbackground=[("disabled", SURFACE)],
    )

    style.configure(
        "TCombobox",
        fieldbackground=SURFACE_ALT,
        background=SURFACE_ALT,
        foreground=TEXT,
        arrowcolor=TEXT_MUTED,
        bordercolor=BORDER,
        lightcolor=BORDER,
        darkcolor=BORDER,
        borderwidth=1,
        padding=5,
    )
    style.map(
        "TCombobox",
        fieldbackground=[("readonly", SURFACE_ALT)],
        foreground=[("readonly", TEXT)],
        bordercolor=[("focus", ACCENT)],
    )


def _style_tree(style):
    style.configure(
        "Treeview",
        background=SURFACE,
        fieldbackground=SURFACE,
        foreground=TEXT,
        borderwidth=0,
        relief="flat",
        rowheight=30,
        font=F_BODY,
    )
    style.map(
        "Treeview",
        background=[("selected", ACCENT_ACTIVE)],
        foreground=[("selected", "#ffffff")],
    )
    style.configure(
        "Treeview.Heading",
        background=SURFACE_ALT,
        foreground=TEXT_MUTED,
        borderwidth=0,
        relief="flat",
        padding=(10, 9),
        font=F_SMALL_BOLD,
    )
    style.map("Treeview.Heading", background=[("active", BORDER)])


def _style_scrollbar(style):
    style.configure(
        "Vertical.TScrollbar",
        background=SURFACE_ALT,
        troughcolor=SURFACE,
        bordercolor=SURFACE,
        arrowcolor=TEXT_MUTED,
        borderwidth=0,
        relief="flat",
        width=11,
    )
    style.map("Vertical.TScrollbar", background=[("active", BORDER)])
