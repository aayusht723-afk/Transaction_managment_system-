"""Popups: the add/edit form and the summary report window."""

import tkinter as tk
from datetime import datetime
from tkinter import ttk

from config import TXN_TYPES
from ui import theme as t
from ui.widgets import SegmentedControl, make_button

BAR_BLOCKS = 16


class TransactionDialog(tk.Toplevel):
    """Add or edit form. Validation errors appear inline, not in a popup."""

    def __init__(self, master, title, data=None):
        super().__init__(master)
        self.result = None

        current = data or {
            "txn_date": datetime.now().strftime("%Y-%m-%d"),
            "txn_type": "expense",
            "category": "",
            "amount": "",
            "note": "",
        }

        self.title(title)
        self.configure(bg=t.SURFACE)
        self.resizable(False, False)
        self.transient(master)

        body = tk.Frame(self, bg=t.SURFACE)
        body.pack(fill="both", expand=True, padx=24, pady=22)

        tk.Label(body, text=title, bg=t.SURFACE, fg=t.TEXT, font=t.F_SECTION).pack(anchor="w")
        tk.Label(
            body, text="Fields marked with a dot are required.", bg=t.SURFACE,
            fg=t.TEXT_MUTED, font=t.F_SMALL,
        ).pack(anchor="w", pady=(4, 16))

        form = tk.Frame(body, bg=t.SURFACE)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        amount = current["amount"]
        self.var_date = tk.StringVar(value=current["txn_date"])
        self.var_type = tk.StringVar(value=current["txn_type"])
        self.var_category = tk.StringVar(value=current["category"])
        self.var_amount = tk.StringVar(value="" if amount == "" else f"{float(amount):.2f}")
        self.var_note = tk.StringVar(value=current["note"])

        self._entry(form, 0, "Date", self.var_date)
        category_entry = self._entry(form, 1, "Category", self.var_category)

        self._label(form, 2, "Type")
        SegmentedControl(
            form,
            [("income", "Income"), ("expense", "Expense")],
            self.var_type,
            {"income": t.INCOME, "expense": t.EXPENSE},
        ).grid(row=2, column=1, sticky="w", pady=6)

        amount_entry = self._entry(form, 3, "Amount", self.var_amount)

        self._label(form, 4, "Note")
        ttk.Entry(form, textvariable=self.var_note, width=34).grid(row=4, column=1, sticky="ew", pady=6)

        self._error = tk.Label(body, text="", bg=t.SURFACE, fg=t.EXPENSE, font=t.F_SMALL)
        self._error.pack(anchor="w", pady=(10, 0))

        buttons = tk.Frame(body, bg=t.SURFACE)
        buttons.pack(fill="x", pady=(14, 0))
        make_button(buttons, "Save", self._save, "primary", width=10).pack(side="right")
        make_button(buttons, "Cancel", self.destroy, "ghost", width=10).pack(side="right", padx=(0, 8))

        self.bind("<Return>", lambda event: self._save())
        self.bind("<Escape>", lambda event: self.destroy())

        self.grab_set()
        self.update_idletasks()
        self._center_on(master)

        # Put the cursor where the user most likely needs to type.
        target = amount_entry if current["category"] else category_entry
        target.focus_set()

    def _label(self, form, row, text):
        tk.Label(form, text=text, bg=t.SURFACE, fg=t.TEXT_MUTED, font=t.F_SMALL).grid(
            row=row, column=0, sticky="w", pady=6, padx=(0, 14)
        )

    def _entry(self, form, row, text, variable):
        self._label(form, row, text)
        entry = ttk.Entry(form, textvariable=variable, width=34)
        entry.grid(row=row, column=1, sticky="ew", pady=6)
        return entry

    def _save(self):
        try:
            txn_date = datetime.strptime(self.var_date.get().strip(), "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            self._fail("Date must look like 2026-05-14.")
            return

        try:
            amount = round(float(self.var_amount.get().strip()), 2)
        except ValueError:
            self._fail("Amount must be a number, for example 1500 or 250.75.")
            return

        if amount <= 0:
            self._fail("Amount must be greater than zero.")
            return

        self.result = {
            "txn_date": txn_date,
            "txn_type": self.var_type.get() if self.var_type.get() in TXN_TYPES else "expense",
            "category": self.var_category.get().strip().title() or "Uncategorised",
            "amount": amount,
            "note": self.var_note.get().strip(),
        }
        self.destroy()

    def _fail(self, message):
        self._error.configure(text=message)
        self.bell()

    def _center_on(self, master):
        x = master.winfo_rootx() + (master.winfo_width() - self.winfo_width()) // 2
        y = master.winfo_rooty() + (master.winfo_height() - self.winfo_height()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")


class SummaryWindow(tk.Toplevel):
    """Read-only report: totals, category split and month split."""

    def __init__(self, master, data):
        super().__init__(master)

        self.title("Summary Report")
        self.configure(bg=t.BG)
        self.geometry("660x640")
        self.minsize(600, 560)
        self.transient(master)

        header = tk.Frame(self, bg=t.BG)
        header.pack(fill="x", padx=20, pady=(18, 0))
        tk.Label(header, text="Summary report", bg=t.BG, fg=t.TEXT, font=t.F_TITLE).pack(anchor="w")
        tk.Label(
            header, text="Everything currently stored, ignoring the main window filters.",
            bg=t.BG, fg=t.TEXT_MUTED, font=t.F_SMALL,
        ).pack(anchor="w", pady=(2, 0))

        self._totals(data)
        self._breakdown(
            "By category", "Category",
            [(row["label"], row["earned"], row["spent"]) for row in data["by_category"]],
            data["total_expense"],
        )
        self._breakdown(
            "By month", "Month",
            [(row["label"], row["earned"], row["spent"]) for row in data["by_month"]],
            data["total_expense"],
        )

        make_button(self, "Close", self.destroy, "ghost", width=12).pack(pady=16)

        self.bind("<Escape>", lambda event: self.destroy())

    def _totals(self, data):
        row = tk.Frame(self, bg=t.BG)
        row.pack(fill="x", padx=20, pady=(16, 4))

        balance_color = t.INCOME if data["balance"] >= 0 else t.EXPENSE
        cards = (
            ("Income", f"{data['total_income']:,.2f}", t.INCOME),
            ("Expense", f"{data['total_expense']:,.2f}", t.EXPENSE),
            ("Net balance", f"{data['balance']:,.2f}", balance_color),
            ("Records", str(data["count"]), t.ACCENT),
        )
        for index, (caption, value, color) in enumerate(cards):
            card = tk.Frame(row, bg=t.SURFACE, highlightbackground=t.BORDER, highlightthickness=1)
            card.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 8, 0))
            row.columnconfigure(index, weight=1)

            tk.Label(card, text=caption.upper(), bg=t.SURFACE, fg=t.TEXT_MUTED, font=t.F_SMALL_BOLD).pack(
                anchor="w", padx=12, pady=(10, 0)
            )
            tk.Label(card, text=value, bg=t.SURFACE, fg=color, font=(t.FONT, 13, "bold")).pack(
                anchor="w", padx=12, pady=(0, 10)
            )

    def _breakdown(self, title, name_header, rows, total_expense):
        box = tk.Frame(self, bg=t.SURFACE, highlightbackground=t.BORDER, highlightthickness=1)
        box.pack(fill="both", expand=True, padx=20, pady=(14, 0))

        tk.Label(box, text=title, bg=t.SURFACE, fg=t.TEXT, font=t.F_SECTION).pack(
            anchor="w", padx=14, pady=(12, 8)
        )

        tree = ttk.Treeview(
            box, columns=("name", "earned", "spent", "share"),
            show="headings", height=5, selectmode="none",
        )
        for key, text, width, anchor in (
            ("name", name_header, 150, "w"),
            ("earned", "Income", 110, "e"),
            ("spent", "Expense", 110, "e"),
            ("share", "Share of expense", 170, "w"),
        ):
            tree.heading(key, text=text)
            tree.column(key, width=width, anchor=anchor, stretch=(key == "share"))

        for name, earned, spent in rows:
            share = spent / total_expense if total_expense else 0
            bar = f"{'█' * round(share * BAR_BLOCKS)} {share * 100:.0f}%" if spent else ""
            tree.insert(
                "", "end",
                values=(name, f"{earned:,.2f}", f"{spent:,.2f}", bar),
                tags=("income" if earned and not spent else "expense",),
            )

        tree.tag_configure("income", foreground=t.INCOME)
        tree.tag_configure("expense", foreground=t.EXPENSE)
        tree.pack(fill="both", expand=True, padx=14, pady=(0, 14))
