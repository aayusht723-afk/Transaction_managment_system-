"""User interface package for the Transaction Management System."""
