"""Reusable UI pieces: buttons, cards, segmented control and popups."""

import tkinter as tk
from tkinter import ttk

from ui import theme as t


def make_button(parent, text, command, kind="ghost", width=None):
    """Flat button with a hover state. 'primary' is the accent button."""
    palettes = {
        "primary": (t.ACCENT, "#ffffff", t.ACCENT_HOVER),
        "ghost": (t.SURFACE_ALT, t.TEXT, t.SURFACE_HOVER),
        "danger": ("#3a2530", t.EXPENSE, "#4a2f3c"),
    }
    bg, fg, hover = palettes[kind]

    button = tk.Button(
        parent, text=text, command=command,
        bg=bg, fg=fg, activebackground=hover, activeforeground=fg,
        relief="flat", borderwidth=0, highlightthickness=0, cursor="hand2",
        font=t.F_BOLD if kind == "primary" else t.F_BODY,
        padx=14, pady=7, disabledforeground=t.TEXT_MUTED,
    )
    if width:
        button.configure(width=width)

    button.bind("<Enter>", lambda event: button.configure(bg=hover))
    button.bind("<Leave>", lambda event: button.configure(bg=bg))
    return button


class StatCard(tk.Frame):
    """Small metric card: a caption on top and a large value underneath."""

    def __init__(self, master, caption, color=t.TEXT):
        super().__init__(master, bg=t.SURFACE, highlightbackground=t.BORDER, highlightthickness=1)

        tk.Label(
            self, text=caption.upper(), bg=t.SURFACE, fg=t.TEXT_MUTED, font=t.F_SMALL_BOLD
        ).pack(anchor="w", padx=16, pady=(13, 0))

        self._value = tk.StringVar(value="0.00")
        self._label = tk.Label(
            self, textvariable=self._value, bg=t.SURFACE, fg=color, font=t.F_CARD
        )
        self._label.pack(anchor="w", padx=16, pady=(2, 13))

    def set(self, text, color=None):
        self._value.set(text)
        if color:
            self._label.configure(fg=color)


class SegmentedControl(tk.Frame):
    """Row of toggle buttons acting as a single choice selector."""

    def __init__(self, master, options, variable, colors=None):
        super().__init__(master, bg=t.SURFACE_ALT, highlightbackground=t.BORDER, highlightthickness=1)

        colors = colors or {}
        self._variable = variable
        self._buttons = {}

        for value, label in options:
            button = tk.Button(
                self, text=label, command=lambda v=value: variable.set(v),
                relief="flat", borderwidth=0, highlightthickness=0, cursor="hand2",
                font=t.F_BOLD, padx=16, pady=6,
            )
            button.pack(side="left", padx=1, pady=1)
            self._buttons[value] = (button, colors.get(value, t.ACCENT))

        variable.trace_add("write", lambda *_: self._refresh())
        self._refresh()

    def _refresh(self):
        current = self._variable.get()
        for value, (button, color) in self._buttons.items():
            if value == current:
                button.configure(
                    bg=color, fg=t.TEXT_DARK,
                    activebackground=color, activeforeground=t.TEXT_DARK,
                )
            else:
                button.configure(
                    bg=t.SURFACE_ALT, fg=t.TEXT_MUTED,
                    activebackground=t.SURFACE_HOVER, activeforeground=t.TEXT,
                )


class PlaceholderEntry(ttk.Entry):
    """Entry that shows grey hint text while it is empty.

    value() returns an empty string while the hint is visible, so callers never
    end up filtering on the placeholder text.
    """

    def __init__(self, master, placeholder, textvariable, **kwargs):
        super().__init__(master, textvariable=textvariable, **kwargs)
        self._placeholder = placeholder
        self._var = textvariable
        self._showing_hint = False

        self.bind("<FocusIn>", self._on_focus_in)
        self.bind("<FocusOut>", self._on_focus_out)
        self._var.trace_add("write", self._on_var_change)
        self._show_hint()

    def value(self):
        return "" if self._showing_hint else self._var.get().strip()

    def clear(self):
        self._var.set("")
        self._showing_hint = False
        self.configure(foreground=t.TEXT)
        if self.focus_get() is not self:
            self._show_hint()

    def _show_hint(self):
        self._showing_hint = True
        self._var.set(self._placeholder)
        self.configure(foreground=t.TEXT_MUTED)

    def _on_focus_in(self, _event):
        if self._showing_hint:
            self._showing_hint = False
            self._var.set("")
            self.configure(foreground=t.TEXT)

    def _on_focus_out(self, _event):
        if not self._var.get().strip():
            self._show_hint()

    def _on_var_change(self, *_args):
        # Keeps the hint flag honest when the text is set from code as well.
        if self._showing_hint and self._var.get() != self._placeholder:
            self._showing_hint = False
            self.configure(foreground=t.TEXT)


class StatusBar(tk.Frame):
    """Bottom bar. Shows record stats, or a temporary message after an action."""

    def __init__(self, master, right_text):
        super().__init__(master, bg=t.BG)

        self._stats = ""
        self._flash_job = None

        self._left = tk.Label(self, bg=t.BG, fg=t.TEXT_MUTED, font=t.F_SMALL)
        self._left.pack(side="left")

        tk.Label(self, text=right_text, bg=t.BG, fg=t.TEXT_MUTED, font=t.F_SMALL).pack(side="right")

    def set_stats(self, text):
        self._stats = text
        if self._flash_job is None:
            self._left.configure(text=text, fg=t.TEXT_MUTED)

    def flash(self, text, color=t.INCOME):
        if self._flash_job is not None:
            self.after_cancel(self._flash_job)
        self._left.configure(text=text, fg=color)
        self._flash_job = self.after(3200, self._restore)

    def _restore(self):
        self._flash_job = None
        self._left.configure(text=self._stats, fg=t.TEXT_MUTED)


class ConfirmDialog(tk.Toplevel):
    """Styled replacement for messagebox.askyesno()."""

    def __init__(self, master, title, heading, message, confirm_text="Delete"):
        super().__init__(master)
        self.confirmed = False

        self.title(title)
        self.configure(bg=t.SURFACE)
        self.resizable(False, False)
        self.transient(master)

        body = tk.Frame(self, bg=t.SURFACE)
        body.pack(fill="both", expand=True, padx=22, pady=20)

        tk.Label(body, text=heading, bg=t.SURFACE, fg=t.TEXT, font=t.F_SECTION).pack(anchor="w")
        tk.Label(
            body, text=message, bg=t.SURFACE, fg=t.TEXT_MUTED, font=t.F_BODY,
            justify="left", wraplength=330,
        ).pack(anchor="w", pady=(8, 18))

        buttons = tk.Frame(body, bg=t.SURFACE)
        buttons.pack(fill="x")
        make_button(buttons, confirm_text, self._confirm, "danger", width=10).pack(side="right")
        make_button(buttons, "Cancel", self.destroy, "ghost", width=10).pack(side="right", padx=(0, 8))

        self.bind("<Return>", lambda event: self._confirm())
        self.bind("<Escape>", lambda event: self.destroy())

        self.grab_set()
        self._center_on(master)

    def _confirm(self):
        self.confirmed = True
        self.destroy()

    def _center_on(self, master):
        self.update_idletasks()
        x = master.winfo_rootx() + (master.winfo_width() - self.winfo_width()) // 2
        y = master.winfo_rooty() + (master.winfo_height() - self.winfo_height()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
