"""Main application window."""

import tkinter as tk
from tkinter import ttk

from config import CSV_FILE, STORAGE
from reports import write_csv
from storage import get_store
from ui import theme as t
from ui.dialogs import SummaryWindow, TransactionDialog
from ui.widgets import (
    ConfirmDialog,
    PlaceholderEntry,
    SegmentedControl,
    StatCard,
    StatusBar,
    make_button,
)

PAD = 16

# key -> (heading, width, anchor, sort key)
COLUMNS = {
    "id": ("ID", 60, "center", lambda row: row["id"]),
    "date": ("Date", 110, "center", lambda row: row["txn_date"]),
    "type": ("Type", 100, "center", lambda row: row["txn_type"]),
    "category": ("Category", 190, "w", lambda row: row["category"].lower()),
    "amount": ("Amount", 140, "e", lambda row: row["amount"]),
    "note": ("Note", 320, "w", lambda row: row["note"].lower()),
}


class TransactionApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.store = get_store()

        self.rows = []
        self.sort_column = "date"
        self.sort_reverse = True
        self._hover_row = None
        self._row_tags = {}

        self.title("Transaction Management System")
        self.configure(bg=t.BG)
        self.geometry("1080x700")
        self.minsize(940, 580)

        t.apply_theme(self)

        self._build_header()
        self._build_cards()
        self._build_filters()
        self._build_table()
        self._build_statusbar()
        self._bind_shortcuts()

        self.refresh()
        self._center_on_screen()

    # ------------------------------------------------------------------ layout

    def _build_header(self):
        header = tk.Frame(self, bg=t.BG)
        header.pack(fill="x", padx=PAD, pady=(PAD, 2))

        titles = tk.Frame(header, bg=t.BG)
        titles.pack(side="left")
        tk.Label(
            titles, text="Transaction Management", bg=t.BG, fg=t.TEXT, font=t.F_TITLE
        ).pack(anchor="w")
        tk.Label(
            titles, text="Money in, money out, all in one place",
            bg=t.BG, fg=t.TEXT_MUTED, font=t.F_SMALL,
        ).pack(anchor="w", pady=(2, 0))

        actions = tk.Frame(header, bg=t.BG)
        actions.pack(side="right")
        make_button(actions, "Export CSV", self.export_csv).pack(side="right", padx=(8, 0))
        make_button(actions, "Summary", self.show_summary).pack(side="right", padx=(8, 0))
        make_button(actions, "Add Transaction", self.add_transaction, "primary").pack(side="right")

    def _build_cards(self):
        row = tk.Frame(self, bg=t.BG)
        row.pack(fill="x", padx=PAD, pady=(14, 0))

        self.card_income = StatCard(row, "Income", t.INCOME)
        self.card_expense = StatCard(row, "Expense", t.EXPENSE)
        self.card_balance = StatCard(row, "Net balance", t.ACCENT)
        self.card_count = StatCard(row, "Records", t.TEXT)

        for index, card in enumerate(
            (self.card_income, self.card_expense, self.card_balance, self.card_count)
        ):
            card.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 12, 0))
            row.columnconfigure(index, weight=1)

    def _build_filters(self):
        box = tk.Frame(self, bg=t.SURFACE, highlightbackground=t.BORDER, highlightthickness=1)
        box.pack(fill="x", padx=PAD, pady=(14, 0))

        inner = tk.Frame(box, bg=t.SURFACE)
        inner.pack(fill="x", padx=14, pady=12)

        self.var_search = tk.StringVar()
        self.var_type = tk.StringVar(value="all")
        self.var_from = tk.StringVar()
        self.var_to = tk.StringVar()

        search_box = tk.Frame(inner, bg=t.SURFACE)
        search_box.pack(side="left", fill="x", expand=True)
        self._caption(search_box, "Search category")
        self.search = PlaceholderEntry(
            search_box, "Type a category name...", self.var_search, width=26
        )
        self.search.pack(fill="x", pady=(4, 0))
        self.search.bind("<KeyRelease>", lambda event: self.apply_filters())

        type_box = tk.Frame(inner, bg=t.SURFACE)
        type_box.pack(side="left", padx=(16, 0))
        self._caption(type_box, "Type")
        SegmentedControl(
            type_box,
            [("all", "All"), ("income", "Income"), ("expense", "Expense")],
            self.var_type,
            {"all": t.ACCENT, "income": t.INCOME, "expense": t.EXPENSE},
        ).pack(pady=(4, 0))

        self._date_box(inner, "From", self.var_from, (16, 0))
        self._date_box(inner, "To", self.var_to, (12, 0))

        reset_box = tk.Frame(inner, bg=t.SURFACE)
        reset_box.pack(side="left", padx=(16, 0))
        self._caption(reset_box, " ")
        make_button(reset_box, "Reset", self.reset_filters).pack(pady=(4, 0))

    def _caption(self, parent, text):
        tk.Label(parent, text=text.upper(), bg=t.SURFACE, fg=t.TEXT_MUTED, font=t.F_SMALL_BOLD).pack(
            anchor="w"
        )

    def _date_box(self, parent, caption, variable, padding):
        box = tk.Frame(parent, bg=t.SURFACE)
        box.pack(side="left", padx=padding)
        self._caption(box, caption)
        entry = ttk.Entry(box, textvariable=variable, width=13)
        entry.pack(pady=(4, 0))
        entry.bind("<KeyRelease>", lambda event: self.apply_filters())

    def _build_table(self):
        container = tk.Frame(self, bg=t.SURFACE, highlightbackground=t.BORDER, highlightthickness=1)
        container.pack(fill="both", expand=True, padx=PAD, pady=(14, 0))

        self.tree = ttk.Treeview(
            container, columns=tuple(COLUMNS), show="headings", selectmode="browse"
        )
        for key, (heading, width, anchor, _) in COLUMNS.items():
            self.tree.heading(key, text=heading, command=lambda k=key: self.sort_by(k))
            self.tree.column(
                key, width=width, anchor=anchor, minwidth=60, stretch=key in ("category", "note")
            )

        self.tree.tag_configure("odd", background=t.SURFACE_ALT)
        self.tree.tag_configure("income", foreground=t.INCOME)
        self.tree.tag_configure("expense", foreground=t.EXPENSE)
        self.tree.tag_configure("hover", background=t.SURFACE_HOVER)

        scroll = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=1, pady=1)
        scroll.pack(side="right", fill="y")

        self.tree.bind("<Double-1>", self._on_double_click)
        self.tree.bind("<Motion>", self._on_hover)
        self.tree.bind("<Leave>", lambda event: self._clear_hover())
        self.tree.bind("<Button-3>", self._on_right_click)
        self.tree.bind("<Delete>", lambda event: self.delete_transaction())

        self.empty_label = tk.Label(
            container, text="", bg=t.SURFACE, fg=t.TEXT_MUTED, font=t.F_BODY, justify="center"
        )

    def _build_statusbar(self):
        mode = STORAGE.upper()
        if STORAGE == "memory":
            mode += " (cleared on exit)"

        self.status = StatusBar(self, f"Storage: {mode}     Ctrl+N add  |  F5 refresh  |  Ctrl+S export")
        self.status.pack(fill="x", padx=PAD, pady=(8, PAD))

    def _bind_shortcuts(self):
        self.bind("<Control-n>", lambda event: self.add_transaction())
        self.bind("<Control-e>", lambda event: self.edit_transaction())
        self.bind("<Control-f>", lambda event: self.search.focus_set())
        self.bind("<Control-s>", lambda event: self.export_csv())
        self.bind("<F5>", lambda event: self.refresh())
        self.bind("<Escape>", lambda event: self.reset_filters())

    # ------------------------------------------------------------------ data

    def refresh(self):
        self._all_rows = self.store.all_rows()
        self.rows = self._all_rows
        self.render()

    def apply_filters(self):
        self._all_rows = self.store.all_rows()
        txn_type = self.var_type.get()
        self.rows = self.store.search(
            txn_type="" if txn_type == "all" else txn_type,
            category=self.search.value(),
            start=self.var_from.get().strip(),
            end=self.var_to.get().strip(),
        )
        self.render()

    def reset_filters(self):
        self.var_type.set("all")
        self.var_from.set("")
        self.var_to.set("")
        self.search.clear()
        self.refresh()

    def render(self):
        rows = sorted(self.rows, key=COLUMNS[self.sort_column][3], reverse=self.sort_reverse)

        self.tree.delete(*self.tree.get_children())
        self._row_tags.clear()

        for index, row in enumerate(rows):
            tags = []
            if index % 2:
                tags.append("odd")
            tags.append(row["txn_type"])
            self.tree.insert(
                "", "end", iid=str(row["id"]),
                values=(
                    row["id"],
                    row["txn_date"],
                    row["txn_type"].capitalize(),
                    row["category"],
                    f"{'+' if row['txn_type'] == 'income' else '-'}{row['amount']:,.2f}",
                    row["note"],
                ),
                tags=tuple(tags),
            )
            self._row_tags[str(row["id"])] = tuple(tags)

        self._refresh_headings()
        self._update_cards(rows)
        self._update_empty_state(rows)
        self.status.set_stats(f"Showing {len(rows)} of {len(self._all_rows)} record(s)")

    def _refresh_headings(self):
        for key, (heading, _, _, _) in COLUMNS.items():
            arrow = ""
            if key == self.sort_column:
                arrow = "  ▼" if self.sort_reverse else "  ▲"
            self.tree.heading(key, text=heading + arrow)

    def _update_cards(self, rows):
        income = sum(row["amount"] for row in rows if row["txn_type"] == "income")
        expense = sum(row["amount"] for row in rows if row["txn_type"] == "expense")
        balance = income - expense

        self.card_income.set(f"{income:,.2f}", t.INCOME)
        self.card_expense.set(f"{expense:,.2f}", t.EXPENSE)
        self.card_balance.set(f"{balance:,.2f}", t.INCOME if balance >= 0 else t.EXPENSE)
        self.card_count.set(str(len(rows)), t.TEXT)

    def _update_empty_state(self, rows):
        if rows:
            self.empty_label.place_forget()
        else:
            text = (
                "No records match your filters.\nTry Reset to see everything again."
                if self._all_rows
                else 'No transactions yet.\nClick "Add Transaction" to create the first one.'
            )
            self.empty_label.configure(text=text)
            self.empty_label.place(relx=0.5, rely=0.5, anchor="center")

    def sort_by(self, column):
        if self.sort_column == column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_column = column
            self.sort_reverse = column in ("id", "date", "amount")
        self.render()

    # ------------------------------------------------------------------ actions

    def add_transaction(self):
        dialog = TransactionDialog(self, "Add transaction")
        self.wait_window(dialog)
        if not dialog.result:
            return

        new_id = self.store.add(dialog.result)
        self.refresh()
        self._select(new_id)
        self.status.flash(f"Transaction #{new_id} added")

    def edit_transaction(self):
        row = self._selected_row()
        if row is None:
            return

        dialog = TransactionDialog(self, f"Edit transaction #{row['id']}", row)
        self.wait_window(dialog)
        if not dialog.result:
            return

        self.store.update(row["id"], dialog.result)
        self.refresh()
        self._select(row["id"])
        self.status.flash(f"Transaction #{row['id']} updated")

    def delete_transaction(self):
        row = self._selected_row()
        if row is None:
            return

        dialog = ConfirmDialog(
            self,
            "Delete transaction",
            "Delete this transaction?",
            f"#{row['id']}   {row['txn_date']}   {row['category']}\n"
            f"{row['amount']:,.2f}   {row['note']}",
        )
        self.wait_window(dialog)
        if not dialog.confirmed:
            return

        self.store.delete(row["id"])
        self.refresh()
        self.status.flash(f"Transaction #{row['id']} deleted", t.EXPENSE)

    def export_csv(self):
        count = write_csv()
        if count == 0:
            self.status.flash("Nothing to export yet", t.WARNING)
            return
        self.status.flash(f"{count} record(s) exported to {CSV_FILE}")

    def show_summary(self):
        SummaryWindow(self, self.store.summary())

    # ------------------------------------------------------------------ helpers

    def _selected_row(self):
        selection = self.tree.selection()
        if not selection:
            self.status.flash("Select a transaction in the table first", t.WARNING)
            return None
        return self.store.get(int(selection[0]))

    def _select(self, txn_id):
        if str(txn_id) in self.tree.get_children():
            self.tree.selection_set(str(txn_id))
            self.tree.see(str(txn_id))

    def _on_double_click(self, event):
        if self.tree.identify_region(event.x, event.y) == "cell":
            self.edit_transaction()

    def _on_hover(self, event):
        row = self.tree.identify_row(event.y)
        if row == self._hover_row:
            return
        self._clear_hover()
        if row:
            self.tree.item(row, tags=self._row_tags[row] + ("hover",))
            self._hover_row = row

    def _clear_hover(self):
        if self._hover_row and self.tree.exists(self._hover_row):
            self.tree.item(self._hover_row, tags=self._row_tags[self._hover_row])
        self._hover_row = None

    def _on_right_click(self, event):
        row = self.tree.identify_row(event.y)
        if not row:
            return

        self.tree.selection_set(row)
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Edit transaction", command=self.edit_transaction)
        menu.add_command(label="Summary report", command=self.show_summary)
        menu.add_separator()
        menu.add_command(label="Delete transaction", command=self.delete_transaction)

        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _center_on_screen(self):
        self.update_idletasks()
        x = (self.winfo_screenwidth() - self.winfo_width()) // 2
        y = max((self.winfo_screenheight() - self.winfo_height()) // 2 - 30, 0)
        self.geometry(f"+{x}+{y}")
