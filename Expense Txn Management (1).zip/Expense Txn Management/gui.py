from ui.app import TransactionApp


def main():
    TransactionApp().mainloop()


if __name__ == "__main__":
    main()
