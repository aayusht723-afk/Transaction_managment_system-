# Transaction Management System

A simple desktop application for recording and managing income and expense
transactions. It has a graphical interface (Tkinter) and a command line
interface, and it keeps all data-logic behind a single storage layer so the
database can be swapped without touching the rest of the code.

## Features

- Add, edit and delete transactions
- Stat cards across the top showing income, expense, net balance and record count
- Table with coloured rows, hover highlight, click-to-sort columns and a right-click menu
- Live filtering by type, category and date range as you type
- Summary report with totals, category split and month split, including share bars
- Export all records to a CSV file that opens in Excel
- Input validation everywhere: dates must be `YYYY-MM-DD`, amounts must be
  positive numbers, type must be income or expense
- Two storage backends out of the box: in-memory (default) and SQLite

## Requirements

- Python 3.8 or newer
- No third-party packages. Everything uses the standard library
  (`tkinter`, `sqlite3`, `csv`, `datetime`).

See `requirements.txt` for details.

## How to run

### Desktop app (recommended)

```
python gui.py
```

A dark themed window opens with the action buttons on the right, metric cards
under the title, the filter bar below that, the transaction table in the middle
and status information at the bottom.

- **Add Transaction / Edit** open a popup form. `Enter` saves, `Esc` cancels.
  Validation messages appear inside the form instead of in a separate popup.
- **Click a column heading** to sort by it; click again to reverse the order.
  The active column shows an arrow.
- **Double-click a row** to edit it. **Right-click** a row for edit, summary
  and delete.
- **Delete** asks for confirmation in a styled dialog before removing anything.
- **Summary** opens a report window with totals, a category split and a month
  split, each with a share-of-expense bar.
- **Export CSV** writes `transactions_export.csv` next to the code.
- Filters apply as you type; **Reset** clears them. Totals in the cards always
  describe what is currently visible.

Keyboard shortcuts:

| Key | Action |
| --- | --- |
| `Ctrl+N` | Add transaction |
| `Ctrl+E` | Edit the selected transaction |
| `Delete` | Delete the selected transaction |
| `Ctrl+F` | Jump to the search box |
| `Ctrl+S` | Export to CSV |
| `F5` | Reload from storage |
| `Esc` | Reset filters |

### Command line version

```
python main.py
```

Pick an option from the numbered menu (1-7, 0 to exit).

## Storage modes

The backend is chosen in `config.py` or with an environment variable, so the
same code runs with or without a database.

| Mode | Where data lives | Use it for |
| --- | --- | --- |
| `memory` (default) | RAM only, cleared when you close the app | Quick testing, no database setup |
| `sqlite` | `transactions.db` in the project folder | Keeping data between runs |

Switch with an environment variable:

```powershell
$env:TXN_STORAGE = "sqlite"
python gui.py
```

Or edit `config.py`:

```python
STORAGE = "sqlite"
```

The current mode is always shown in the bottom-right corner of the window.

## Project structure

```
main.py                     Command line interface (menu loop)
gui.py                      Entry point for the desktop app
config.py                   Paths, transaction types, storage mode
utils.py                    CLI input helpers and table printing
transactions.py             Add / view / search / update / delete (CLI)
reports.py                  Summary report and CSV export
ui/
    theme.py                Colours, fonts and ttk styling
    widgets.py              Buttons, stat cards, segmented control, status bar
    dialogs.py              Add/edit form and summary report window
    app.py                  Main window: cards, filters, table, shortcuts
storage/
    __init__.py             Factory that returns the selected backend
    base.py                 Storage interface + shared search and summary
    memory_store.py         In-memory backend (default)
    sqlite_store.py         SQLite backend
requirements.txt            Dependencies (none required)
```

## How the storage layer works

`storage/base.py` defines a small interface. A backend only has to implement
five methods:

```
add(data)               -> new id
all_rows()              -> list of dicts, newest first
get(txn_id)             -> one dict or None
update(txn_id, data)    -> True / False
delete(txn_id)          -> True / False
```

Search and the summary report are written once in `BaseStore` on top of
`all_rows()`, so every backend gets them for free and they can never disagree
between backends.

A transaction is a plain dictionary:

```python
{
    "id": 1,
    "txn_date": "2026-05-14",
    "txn_type": "income",       # or "expense"
    "category": "Salary",
    "amount": 50000.0,
    "note": "Monthly pay",
}
```

## Adding Oracle later

1. Create `storage/oracle_store.py` with a class that extends `BaseStore` and
   implements the five methods using `oracledb` (Python's Oracle driver).
2. Add one branch in `storage/__init__.py`:

```python
elif STORAGE == "oracle":
    from storage.oracle_store import OracleStore

    _store = OracleStore()
```

3. Install the driver and set the mode:

```powershell
pip install oracledb
$env:TXN_STORAGE = "oracle"
```

Nothing in `gui.py`, `main.py`, `transactions.py` or `reports.py` needs to
change, because they only use the interface.

## Notes

- In `memory` mode the data disappears when you close the app. Export to CSV
  first if you want to keep the results.
- In `sqlite` mode the table is created automatically the first time the app
  runs; there is no separate setup step.
- Amounts are rounded to two decimal places.
- Deleting a transaction does not renumber the remaining records; IDs are
  never reused, which keeps the CSV export consistent with the app.
