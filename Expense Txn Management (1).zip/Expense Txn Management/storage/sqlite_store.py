import sqlite3

from config import DB_FILE
from storage.base import BaseStore

CREATE_TABLE = """
    CREATE TABLE IF NOT EXISTS transactions (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        txn_date  TEXT    NOT NULL,
        txn_type  TEXT    NOT NULL CHECK (txn_type IN ('income', 'expense')),
        category  TEXT    NOT NULL,
        amount    REAL    NOT NULL CHECK (amount > 0),
        note      TEXT    DEFAULT ''
    )
"""


class SqliteStore(BaseStore):
    def __init__(self):
        with self._connect() as conn:
            conn.execute(CREATE_TABLE)

    def _connect(self):
        conn = sqlite3.connect(DB_FILE)
        # Reading columns by name means the rows behave like the dicts the
        # other backends return.
        conn.row_factory = sqlite3.Row
        return conn

    def add(self, data):
        with self._connect() as conn:
            cursor = conn.execute(
                "INSERT INTO transactions (txn_date, txn_type, category, amount, note) "
                "VALUES (?, ?, ?, ?, ?)",
                (data["txn_date"], data["txn_type"], data["category"],
                 data["amount"], data["note"]),
            )
            return cursor.lastrowid

    def all_rows(self):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM transactions ORDER BY txn_date DESC, id DESC"
            ).fetchall()
        return [dict(row) for row in rows]

    def get(self, txn_id):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM transactions WHERE id = ?", (txn_id,)
            ).fetchone()
        return dict(row) if row else None

    def update(self, txn_id, data):
        with self._connect() as conn:
            cursor = conn.execute(
                "UPDATE transactions SET txn_date = ?, txn_type = ?, category = ?, "
                "amount = ?, note = ? WHERE id = ?",
                (data["txn_date"], data["txn_type"], data["category"],
                 data["amount"], data["note"], txn_id),
            )
            return cursor.rowcount > 0

    def delete(self, txn_id):
        with self._connect() as conn:
            cursor = conn.execute("DELETE FROM transactions WHERE id = ?", (txn_id,))
            return cursor.rowcount > 0
