class BaseStore:
    """Operations every storage backend has to provide.

    Only add / all_rows / get / update / delete touch real storage.
    Search and summary are worked out from all_rows(), so a new backend
    (Oracle, MySQL, whatever) only needs those five methods.
    """

    def add(self, data):
        raise NotImplementedError

    def all_rows(self):
        raise NotImplementedError

    def get(self, txn_id):
        raise NotImplementedError

    def update(self, txn_id, data):
        raise NotImplementedError

    def delete(self, txn_id):
        raise NotImplementedError

    def search(self, txn_type="", category="", start="", end=""):
        results = []
        for row in self.all_rows():
            if txn_type and row["txn_type"] != txn_type:
                continue
            if category and category.lower() not in row["category"].lower():
                continue
            if start and row["txn_date"] < start:
                continue
            if end and row["txn_date"] > end:
                continue
            results.append(row)
        return results

    def summary(self):
        rows = self.all_rows()

        total_income = 0.0
        total_expense = 0.0
        by_category = {}
        by_month = {}

        for row in rows:
            category = by_category.setdefault(
                row["category"], {"label": row["category"], "earned": 0.0, "spent": 0.0}
            )
            month = by_month.setdefault(
                row["txn_date"][:7],
                {"label": row["txn_date"][:7], "earned": 0.0, "spent": 0.0},
            )

            if row["txn_type"] == "income":
                total_income += row["amount"]
                category["earned"] += row["amount"]
                month["earned"] += row["amount"]
            else:
                total_expense += row["amount"]
                category["spent"] += row["amount"]
                month["spent"] += row["amount"]

        return {
            "count": len(rows),
            "total_income": total_income,
            "total_expense": total_expense,
            "balance": total_income - total_expense,
            "by_category": sorted(by_category.values(), key=lambda r: r["spent"], reverse=True),
            "by_month": sorted(by_month.values(), key=lambda r: r["label"], reverse=True),
        }
