from config import STORAGE

_store = None


def get_store():
    """Return the single storage instance for this run.

    Adding Oracle later means writing oracle_store.py and one branch here.
    """
    global _store

    if _store is None:
        if STORAGE == "memory":
            from storage.memory_store import MemoryStore

            _store = MemoryStore()
        elif STORAGE == "sqlite":
            from storage.sqlite_store import SqliteStore

            _store = SqliteStore()
        else:
            raise ValueError(f"Unknown STORAGE '{STORAGE}'. Use 'memory' or 'sqlite'.")

    return _store
