from storage.base import BaseStore


class MemoryStore(BaseStore):
    """Keeps records in a list. Everything is gone once the program exits."""

    def __init__(self):
        self._rows = []
        self._next_id = 1

    def add(self, data):
        row = {"id": self._next_id, **data}
        self._rows.append(row)
        self._next_id += 1
        return row["id"]

    def all_rows(self):
        return sorted(self._rows, key=lambda r: (r["txn_date"], r["id"]), reverse=True)

    def get(self, txn_id):
        for row in self._rows:
            if row["id"] == txn_id:
                return dict(row)
        return None

    def update(self, txn_id, data):
        for row in self._rows:
            if row["id"] == txn_id:
                row.update(data)
                return True
        return False

    def delete(self, txn_id):
        for index, row in enumerate(self._rows):
            if row["id"] == txn_id:
                del self._rows[index]
                return True
        return False
