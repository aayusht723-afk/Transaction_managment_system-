import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, "transactions.db")
CSV_FILE = os.path.join(BASE_DIR, "transactions_export.csv")

TXN_TYPES = ("income", "expense")

# "memory" keeps records in RAM, nothing is written to disk.
# "sqlite" uses transactions.db.
# An "oracle" backend can be added here later.
STORAGE = os.environ.get("TXN_STORAGE", "memory").strip().lower()
