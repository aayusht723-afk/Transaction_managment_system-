from config import STORAGE
from reports import export_to_csv, show_summary
from storage import get_store
from transactions import (
    add_transaction,
    delete_transaction,
    search_transactions,
    update_transaction,
    view_transactions,
)

MENU = """
==============================================================
            TRANSACTION MANAGEMENT SYSTEM
==============================================================
  1. Add a transaction
  2. View all transactions
  3. Search / filter transactions
  4. Update a transaction
  5. Delete a transaction
  6. Summary report
  7. Export to CSV
  0. Exit
=============================================================="""


def main():
    get_store()

    mode = STORAGE.upper()
    if STORAGE == "memory":
        mode += " (records are cleared when you exit)"
    print(f"\n  Storage mode: {mode}")

    actions = {
        "1": add_transaction,
        "2": view_transactions,
        "3": search_transactions,
        "4": update_transaction,
        "5": delete_transaction,
        "6": show_summary,
        "7": export_to_csv,
    }

    while True:
        print(MENU)
        choice = input("  Choose an option: ").strip()

        if choice == "0":
            print("\n  Data saved. Goodbye!")
            break

        action = actions.get(choice)
        if action is None:
            print("  !! Invalid option, please pick a number from the menu.")
        else:
            action()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        # Ctrl+C should exit quietly instead of showing a traceback.
        print("\n\n  Interrupted. Goodbye!")
