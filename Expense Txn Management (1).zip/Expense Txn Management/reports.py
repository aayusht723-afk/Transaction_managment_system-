import csv

from config import CSV_FILE
from storage import get_store


def show_summary():
    data = get_store().summary()

    print("\n--- Summary Report ---")
    print(f"  Total transactions : {data['count']}")
    print(f"  Total income       : {data['total_income']:>12,.2f}")
    print(f"  Total expense      : {data['total_expense']:>12,.2f}")
    print(f"  Net balance        : {data['balance']:>12,.2f}")

    if data["count"] == 0:
        return

    _print_breakdown("Category wise breakdown", "Category", data["by_category"])
    _print_breakdown("Month wise breakdown", "Month", data["by_month"])


def _print_breakdown(heading, label, rows):
    print(f"\n  {heading}")
    print(f"  {label:<20}{'Income':>12}{'Expense':>12}")
    print("  " + "-" * 44)
    for row in rows:
        print(f"  {row['label'][:19]:<20}{row['earned']:>12,.2f}{row['spent']:>12,.2f}")


def export_to_csv():
    count = write_csv()

    if count == 0:
        print("\n  Nothing to export yet.")
        return

    print(f"\n  {count} record(s) exported to:\n  {CSV_FILE}")


def write_csv():
    """Write every record to the CSV file and return how many were written."""
    rows = sorted(get_store().all_rows(), key=lambda r: (r["txn_date"], r["id"]))
    if not rows:
        return 0

    # newline="" stops Windows from writing a blank line between rows.
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["ID", "Date", "Type", "Category", "Amount", "Note"])
        for row in rows:
            writer.writerow(
                [row["id"], row["txn_date"], row["txn_type"], row["category"],
                 row["amount"], row["note"]]
            )

    return len(rows)
