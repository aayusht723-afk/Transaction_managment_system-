from datetime import datetime

from config import TXN_TYPES
from storage import get_store
from utils import ask, ask_amount, ask_date, ask_int, ask_type, print_table


def add_transaction():
    print("\n--- Add Transaction ---")

    data = {
        "txn_date": ask_date("Date (YYYY-MM-DD) [today]: "),
        "txn_type": ask_type("Type (income/expense): "),
        "category": ask("Category (e.g. Food, Salary, Rent): ").title() or "Uncategorised",
        "amount": ask_amount("Amount: "),
        "note": ask("Note (optional): "),
    }

    new_id = get_store().add(data)
    print(f"\n  Saved! Transaction #{new_id} recorded successfully.")


def view_transactions(rows=None, title="All Transactions"):
    print_table(rows if rows is not None else get_store().all_rows(), title)


def search_transactions():
    print("\n--- Search Transactions ---")
    print("  Press Enter to skip any filter.")

    txn_type = input("  Type (income/expense): ").strip().lower()
    if txn_type not in TXN_TYPES:
        txn_type = ""

    rows = get_store().search(
        txn_type=txn_type,
        category=input("  Category contains: ").strip(),
        start=input("  From date (YYYY-MM-DD): ").strip(),
        end=input("  To date   (YYYY-MM-DD): ").strip(),
    )

    print_table(rows, "Search Results")


def update_transaction():
    view_transactions(title="Pick a Transaction to Update")
    txn_id = ask_int("Enter the ID you want to edit (0 to cancel): ")
    if txn_id == 0:
        return

    store = get_store()
    row = store.get(txn_id)
    if row is None:
        print("  !! No transaction with that ID.")
        return

    print("\n  Leave a field blank to keep the current value.")

    # A blank answer here means "keep the old value", which is not the same as
    # ask_date(), where a blank answer means "today".
    raw_date = input(f"  Date [{row['txn_date']}]: ").strip()
    try:
        new_date = datetime.strptime(raw_date, "%Y-%m-%d").strftime("%Y-%m-%d")
    except ValueError:
        new_date = row["txn_date"]

    raw_type = input(f"  Type [{row['txn_type']}]: ").strip().lower()
    new_type = raw_type if raw_type in TXN_TYPES else row["txn_type"]

    new_category = ask(f"  Category [{row['category']}]: ", row["category"]).title()
    new_amount = _keep_or_change_amount(row["amount"])
    new_note = ask(f"  Note [{row['note']}]: ", row["note"])

    store.update(txn_id, {
        "txn_date": new_date,
        "txn_type": new_type,
        "category": new_category,
        "amount": new_amount,
        "note": new_note,
    })

    print(f"\n  Transaction #{txn_id} updated.")


def _keep_or_change_amount(current):
    raw = input(f"  Amount [{current:,.2f}]: ").strip()
    if not raw:
        return current
    try:
        amount = round(float(raw), 2)
        return amount if amount > 0 else current
    except ValueError:
        print("  !! Not a number, keeping the old amount.")
        return current


def delete_transaction():
    view_transactions(title="Pick a Transaction to Delete")
    txn_id = ask_int("Enter the ID you want to delete (0 to cancel): ")
    if txn_id == 0:
        return

    store = get_store()
    row = store.get(txn_id)
    if row is None:
        print("  !! No transaction with that ID.")
        return

    print(
        f"\n  #{row['id']} | {row['txn_date']} | {row['txn_type']} | "
        f"{row['category']} | {row['amount']:,.2f}"
    )

    if input("  Delete this record? (y/n): ").strip().lower() == "y":
        store.delete(txn_id)
        print(f"  Transaction #{txn_id} deleted.")
    else:
        print("  Cancelled - nothing was deleted.")
