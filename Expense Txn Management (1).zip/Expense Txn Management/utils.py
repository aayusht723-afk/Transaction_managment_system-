from datetime import datetime

from config import TXN_TYPES

LINE = "-" * 62


def ask(prompt, default=""):
    value = input(prompt).strip()
    return value if value else default


def ask_date(prompt):
    while True:
        raw = input(prompt).strip()
        if raw == "":
            return datetime.now().strftime("%Y-%m-%d")
        try:
            return datetime.strptime(raw, "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            print("  !! Invalid date. Please use YYYY-MM-DD (example: 2026-05-14).")


def ask_amount(prompt):
    while True:
        raw = input(prompt).strip()
        try:
            amount = float(raw)
            if amount <= 0:
                print("  !! Amount must be greater than zero.")
                continue
            return round(amount, 2)
        except ValueError:
            print("  !! That is not a number. Try something like 1500 or 250.75")


def ask_type(prompt):
    while True:
        raw = input(prompt).strip().lower()
        if raw in TXN_TYPES:
            return raw
        print("  !! Please type either 'income' or 'expense'.")


def ask_int(prompt):
    try:
        return int(input(prompt).strip())
    except ValueError:
        return -1


def print_table(rows, title):
    print(f"\n--- {title} ---")

    if not rows:
        print("  No transactions found.")
        return

    print(f"{'ID':<5}{'Date':<13}{'Type':<10}{'Category':<18}{'Amount':>12}  Note")
    print(LINE)

    total_income = 0.0
    total_expense = 0.0
    for row in rows:
        if row["txn_type"] == "income":
            total_income += row["amount"]
        else:
            total_expense += row["amount"]

        print(
            f"{row['id']:<5}{row['txn_date']:<13}{row['txn_type']:<10}"
            f"{row['category'][:17]:<18}{row['amount']:>12,.2f}  {row['note']}"
        )

    print(LINE)
    print(f"  Showing {len(rows)} record(s)")
    print(f"  Income : {total_income:>12,.2f}")
    print(f"  Expense: {total_expense:>12,.2f}")
    print(f"  Balance: {total_income - total_expense:>12,.2f}")
